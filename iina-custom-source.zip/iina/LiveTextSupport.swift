//
//  LiveTextSupport.swift
//  iina
//
//  Created by Yuze Jiang on 5/26/25.
//  Copyright © 2025 lhc. All rights reserved.
//

import Cocoa
import VisionKit

fileprivate let subsystem = Logger.makeSubsystem("livetext", ["text.viewfinder"])
fileprivate func liveTextLog(_ str: @autoclosure () -> String, level: Logger.Level = .debug) {
  Logger.log(str, level: level, subsystem: subsystem)
}


@preconcurrency
@MainActor
class LiveTextController: NSObject {
  private weak var mainWindow: MainWindowController!

  var overlayView: NSView?
  var analysisTask: Task<Void, Never>?

  var isSelected: Bool = false
  var isMenuOpen: Bool = false
  var isHighlighted: Bool = false
  var isActive: Bool {
    isSelected || isMenuOpen || isHighlighted
  }
  var isShown: Bool {
    overlayView != nil
  }
  var isAvailable: Bool {
    mainWindow.pipStatus == .notInPIP
      && !mainWindow.interactiveMode.isActive
      && !mainWindow.player.isInMiniPlayer
  }
  private var wasUIHiddenByLiveText: Bool = false

  init(mainWindow: MainWindowController) {
    self.mainWindow = mainWindow
    super.init()

    UserDefaults.standard.addObserver(self, forKeyPath: PK.compactUI.rawValue, context: nil)
  }

  override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    guard let keyPath else { return }

    switch keyPath {
    case PK.compactUI.rawValue:
      updateOverlayInsets()
    default:
      return
    }
  }

  func updateOverlayInsets() {
    guard #available(macOS 13.0, *) else { return }
    guard let view = overlayView as? ImageAnalysisOverlayView else { return }
    let isBottom = Preference.enum(for: .oscPosition) as Preference.OSCPosition == .bottom
    let isCompact = Preference.bool(for: .compactUI)
    let padding: CGFloat = isCompact ? 8 : 14
    let bottomPadding: CGFloat = isBottom ? (isCompact ? 50 : 64) : padding
    view.supplementaryInterfaceContentInsets = NSEdgeInsets(top: padding, left: padding, bottom: bottomPadding, right: padding)
  }

  func requestAnalysis() {
    guard #available(macOS 13.0, *), Preference.isLiveTextEnabled, isAvailable else { return }
    requestAnalysisImpl()
  }

  func clearAnalysis() {
    guard #available(macOS 13.0, *), analysisTask != nil || isShown else { return }
    clearAnalysisImpl()
  }

  func refreshUI() {
    if isActive {
      if !wasUIHiddenByLiveText {
        mainWindow.hideUI(force: true)
        wasUIHiddenByLiveText = true
      }
    } else if wasUIHiddenByLiveText {
      wasUIHiddenByLiveText = false
      if mainWindow.isMouseInWindow {
        mainWindow.showUI()
        mainWindow.updateTimer()
      }
    }
  }
}


@available(macOS 13.0, *)
extension LiveTextController: ImageAnalysisOverlayViewDelegate {
  @discardableResult
  func setupLiveTextOverlay() -> ImageAnalysisOverlayView {
    let view = ImageAnalysisOverlayView()
    view.preferredInteractionTypes = .automatic
    view.delegate = self
    view.translatesAutoresizingMaskIntoConstraints = false
    overlayView = view
    updateOverlayInsets()
    return view
  }

  func requestAnalysisImpl() {
    guard mainWindow.player.info.state == .paused, Preference.isLiveTextEnabled else { return }
    liveTextLog("Image analysis requested")
    analysisTask?.cancel()

    let videoView = mainWindow.videoView
    let videoViewContainer = mainWindow.videoViewContainer!
    analysisTask = Task { [weak self] in
      guard let self else { return }
      do {
        guard let image = await videoView.videoLayer.captureSnapshot() else {
          liveTextLog("Failed to capture frame for image analysis", level: .warning)
          return
        }
        try Task.checkCancellation()
        let analysis = try await ImageAnalyzer().analyze(image, orientation: .up, configuration: .init([.text]))
        try Task.checkCancellation()
        liveTextLog("Image analysis results acquired")
        await MainActor.run {
          guard self.isAvailable, self.mainWindow.player.info.state == .paused else {
            liveTextLog("Image analysis results discarded due to change of player state")
            return
          }
          let overlay = self.setupLiveTextOverlay()
          overlay.analysis = analysis
          overlay.frame = videoViewContainer.bounds
          videoViewContainer.addSubview(overlay)
          overlay.padding(.all(0))
          liveTextLog("Image analysis overlay view inserted to video view")
          self.refreshUI()
        }
      } catch is CancellationError {
        liveTextLog("Image analysis cancelled")
      } catch {
        liveTextLog("Image analysis failed: \(error)", level: .warning)
      }
    }
  }

  func clearAnalysisImpl() {
    analysisTask?.cancel()
    analysisTask = nil
    (overlayView as? ImageAnalysisOverlayView)?.analysis = nil
    overlayView?.removeFromSuperview()
    overlayView = nil
    isSelected = false
    isMenuOpen = false
    isHighlighted = false
    liveTextLog("Image analysis invalidated and overlay view removed from video view")
    refreshUI()
  }

  func overlayView(_ overlayView: ImageAnalysisOverlayView,
                   shouldBeginAt point: CGPoint,
                   forAnalysisType analysisType: ImageAnalysisOverlayView.InteractionTypes) -> Bool {
    return true
  }

  func overlayView(_ overlayView: ImageAnalysisOverlayView, willOpen menu: NSMenu) {
    isMenuOpen = true
    refreshUI()
  }

  func overlayView(_ overlayView: ImageAnalysisOverlayView, didClose menu: NSMenu) {
    isMenuOpen = false
    refreshUI()
  }

  func textSelectionDidChange(_ overlayView: ImageAnalysisOverlayView) {
    isSelected = overlayView.hasActiveTextSelection
    refreshUI()
  }

  func overlayView(_ overlayView: ImageAnalysisOverlayView, highlightSelectedItemsDidChange highlightSelectedItems: Bool) {
    isHighlighted = highlightSelectedItems
    refreshUI()
  }
}
